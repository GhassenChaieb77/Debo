/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IServicerating;

import category.Entite.Category;
import java.sql.SQLException;
import java.util.List;
import rating.entite.Rating;

/**
 *
 * @author ghassen
 */
public interface IServicerating {
     void ajouterrating(Rating t) throws SQLException;
    void deleterating(int id) throws SQLException;
    void updaterating(int idNote,int note,int idProduct) throws SQLException;
    List<Rating> readAllrating() throws SQLException;
}
