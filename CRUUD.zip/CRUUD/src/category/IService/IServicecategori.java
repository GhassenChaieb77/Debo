/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package category.IService;

import category.Entite.Category;
import java.sql.SQLException;
import java.util.List;
import javafx.collections.ObservableList;

/**
 *
 * @author ghassen
 */
public interface IServicecategori<T>  {
        int ajoutercategory(Category t) throws SQLException;
    void deletecategory(int id) throws SQLException;
    void updatecategory(int id,String name) throws SQLException;
    void searchbyidcategory(int id) throws SQLException;
    List<T> sortedbyId() throws SQLException;
    ObservableList<T> readAllcategory() throws SQLException;
}
