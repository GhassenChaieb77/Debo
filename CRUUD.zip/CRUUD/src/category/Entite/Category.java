/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package category.Entite;

/**
 *
 * @author ghassen
 */
public class Category {

   
     private int idcategory;
    private  String categoryName;

    public Category( String categoryName) {
        this.categoryName = categoryName;
    }

    public Category(int idcategory, String categoryName) {
        this.idcategory = idcategory;
        this.categoryName = categoryName;
    }
    
    public Category() {
    }

   

    public int getIdcategory() {
        return idcategory;
    }

    public void setIdcategory(int idcategory) {
        this.idcategory = idcategory;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
   @Override
    public String toString() {
        return "category{" + "idcategory=" + idcategory + ", categoryName=" + categoryName + '}';
    }  
    
}
