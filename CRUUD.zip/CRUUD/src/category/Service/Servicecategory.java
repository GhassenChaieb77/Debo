/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package category.Service;

import Dialog.AlertDialog;
import category.Entite.Category;
import category.IService.IServicecategori;
import deboo.Utils.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;

/**
 *
 * @author ghassen
 */
public class Servicecategory implements IServicecategori<Category>  {
   private Connection con;
    private Statement ste;
    private PreparedStatement pst;

    public Servicecategory() {
        con = DataBase.getInstance().getConnection();

    }
    @Override
    public int ajoutercategory(Category t) throws SQLException  {

        String requeteInsert = "INSERT INTO `debooDB`.`category` (`idcategory`, `categoryName`) VALUES ('" + t.getIdcategory()+ "', '" + t.getCategoryName() + "');";
        int i = 0;   
       try {
           ste = con.createStatement();
           i = ste.executeUpdate(requeteInsert);
           
       } catch (SQLException ex) {
           Logger.getLogger(Servicecategory.class.getName()).log(Level.SEVERE, null, ex);
       }
       finally{ste.close();}
       
       return i;         
    }

   @Override
    public void deletecategory(int id) throws SQLException {
        ste=con.createStatement();
        String sql="DELETE FROM `debooDB`.`category` WHERE idcategory="+id;
                ste.executeUpdate(sql);   

        System.out.println("categorie supprimé , veuillez consulter votre base de données");
        
    }

    @Override
    public void updatecategory(int Idcategory,String categoryName) throws SQLException {
         ste = con.createStatement();
String requestUpdate= "UPDATE debooDB.`category` SET `idcategory`='"+Idcategory+"',`categoryName`='"+categoryName+"' WHERE `idcategory`='"+Idcategory+"';"; 
                  
        
         ste.executeUpdate(requestUpdate);
//       
         System.out.println("categorie modifié, veuillez consulter votre BD");
    }

    @Override
    public ObservableList<Category> readAllcategory()  {
ObservableList<Category> arr = null;
 ResultSet rs=null;
       try {
           pst =con.prepareStatement("Select * from category");

    rs=pst.executeQuery();
     while (rs.next()) {                
             arr.add(new Category(rs.getString("categoryName")));
     }       }
       catch (SQLException ex) {
           Logger.getLogger(Servicecategory.class.getName()).log(Level.SEVERE, null, ex);
       }
    return arr;
    }
   
    @Override
    public void searchbyidcategory(int id) throws SQLException {
 String query="SELECT * FROM category WHERE idCategory='"+id+"'";
        ste=con.createStatement();
     ResultSet rst = ste.executeQuery(query);
        rst.last();
        int nbrRow = rst.getRow();
        if(nbrRow!=0){
            System.out.println("categoie trouve");
        }else{
        System.out.println("categorie non trouve");
        }    }

    @Override
    public List<Category> sortedbyId() throws SQLException {
        List<Category> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from category order by idCategory desc");
     while (rs.next()) {                
               int idcategory=rs.getInt(1);
               String categoryName=rs.getString("categoryName");
               
               
               Category cat=new Category(categoryName);
     arr.add(cat);
     }
    return arr;
    }
 }
    

