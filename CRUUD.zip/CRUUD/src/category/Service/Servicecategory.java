/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package category.Service;

import category.Entite.category;
import category.IService.IServicecategori;
import deboo.Utils.DataBase;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ghassen
 */
public class Servicecategory implements IServicecategori<category>  {
   private Connection con;
    private Statement ste;

    public Servicecategory() {
        con = DataBase.getInstance().getConnection();

    }
    @Override
    public void ajoutercategory(category t) throws SQLException {
ste = con.createStatement();
        String requeteInsert = "INSERT INTO `debooDB`.`category` (`idcategory`, `categoryName`) VALUES ('" + t.getIdcategory()+ "', '" + t.getCategoryName() + "');";
        ste.executeUpdate(requeteInsert);   
    System.out.println("categorie ajoutée, veuillez consulter votre BD");
    }

   @Override
    public void deletecategory(int id) throws SQLException {
        ste=con.createStatement();
        String sql="DELETE FROM `debooDB`.`category` WHERE idcategory="+id;
                ste.executeUpdate(sql);   

        System.out.println("categorie supprimé , veuillez consulter votre base de données");
        
    }

    @Override
    public void updatecategory(int Idcategory,String categoryName) throws SQLException {
         ste = con.createStatement();
String requestUpdate= "UPDATE debooDB.`category` SET `idcategory`='"+Idcategory+"',`categoryName`='"+categoryName+"' WHERE `idcategory`='"+Idcategory+"';"; 
                  
        
         ste.executeUpdate(requestUpdate);
//       
         System.out.println("categorie modifié, veuillez consulter votre BD");
    }

    @Override
    public List<category> readAllcategory() throws SQLException {
List<category> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from category");
     while (rs.next()) {                
               int idcategory=rs.getInt(1);
               String categoryName=rs.getString("categoryName");
               
               
               category cat=new category(idcategory,categoryName);
     arr.add(cat);
     }
    return arr;
    }    }
    

