/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import Produit.entite.Produits;
import Servicerating.Servicerating;
import category.Entite.Category;
import category.Service.Servicecategory;
import deboo.Utils.DataBase;
import java.awt.Image;
import java.sql.SQLException;
import java.util.List;
import produit.Service.Serviceproduits;
import rating.entite.Rating;

/**
 *
 * @author ghassen
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        // TODO code application logic here
        DataBase db=new DataBase();
        
        Servicecategory cat = new Servicecategory();
        Serviceproduits prod = new Serviceproduits();
        Servicerating rate = new Servicerating();
        Category cat1 = new Category(11, "rouge");
        Category cat2 = new Category(12, "rose");
       Produits p1=new Produits(156, "magon1", 50,"D:\\3a13\\CRUUD\\magon.png", 12);
       Produits p2=new Produits(154, "magonn", 40,"D:\\3a13\\CRUUD\\magon.png", 11);
       Rating rate1 = new Rating(12,20,154);
//         
          
            
            try {
//         
            //rate.ajouterrating(rate1);
            //rate.updaterating(12, 0, 154);
            //rate.deleterating(12);
            //cat.ajoutercategory(cat1);
            //cat.ajoutercategory(cat2);
            //cat.deletecategory(11);
           //cat.updatecategory(12, "blanc");
           
           //prod.ajouterproduct(p1);
           //prod.updateproduct(p2);
           //prod.deleteproduct(154);
           //cat.ajoutercategory(cat1);
           prod.searchbyidproduct(155);
           cat.searchbyidcategory(11);
          List<Produits> l1= prod.sortedbyId();
           List<Produits> l=prod.readAllproduct();
            List<Category> list = cat.readAllcategory();
            List<Rating> list1 = rate.readAllrating();
            List<Category> list2 = cat.sortedbyId();
            System.out.println(list);
            System.out.println(list2);
           System.out.println(l);
           System.out.println(l1);
           System.out.println(list1);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
     
    
    }
    
}
