/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import Produit.entite.Produits;
import category.Entite.category;
import category.Service.Servicecategory;
import deboo.Utils.DataBase;
import java.awt.Image;
import java.sql.SQLException;
import java.util.List;
import produit.Service.Serviceproduits;

/**
 *
 * @author ghassen
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        // TODO code application logic here
        DataBase db=new DataBase();
        
        Servicecategory cat = new Servicecategory();
        Serviceproduits prod = new Serviceproduits();
        category cat1 = new category(11, "rouge");
        category cat2 = new category(12, "rose");
       Produits p1=new Produits(154, "magon", 50,"D:\\3a13\\CRUUD\\magon.png", 12);
       Produits p2=new Produits(154, "magonn", 40,"D:\\3a13\\CRUUD\\magon.png", 11);
       
//         
          
            
            try {
//         
            //cat.ajoutercategory(cat1);
            //cat.ajoutercategory(cat2);
            //cat.deletecategory(11);
           //cat.updatecategory(12, "blanc");
           
           //prod.ajouterproduct(p1);
           //prod.updateproduct(p2);
           //prod.deleteproduct(154);
           List<Produits> l=prod.readAllproduct();
            List<category> list = cat.readAllcategory();
            System.out.println(list);
           System.out.println(l);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
     
    
    }
    
}
