/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rating.entite;

/**
 *
 * @author ghassen
 */
public class Rating {
   private int idNote;
   private int note;
   private int idProduct;

    public Rating(int idNote, int note, int idProduct) {
        this.idNote = idNote;
        this.note = note;
        this.idProduct = idProduct;
    }

    public Rating() {
    }

    public int getIdNote() {
        return idNote;
    }

    public void setIdNote(int idNote) {
        this.idNote = idNote;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    @Override
    public String toString() {
        return "Rating{" + "idNote=" + idNote + ", note=" + note + ", idProduct=" + idProduct + '}';
    }
}
