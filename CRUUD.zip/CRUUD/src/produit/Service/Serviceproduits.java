/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produit.Service;

import Produit.entite.Produits;
import category.Entite.Category;
import deboo.Utils.DataBase;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import produit.IService.Iserviceproduits;

/**
 *
 * @author ghassen
 */
public class Serviceproduits implements Iserviceproduits{
 private Connection con;
    private Statement ste;
    PreparedStatement stmt =null;

    public Serviceproduits() {
        con = DataBase.getInstance().getConnection();

    }
  

    @Override
    public void deleteproduct(int id) throws SQLException {
    ste=con.createStatement();
        String sql="DELETE FROM `debooDB`.`product` WHERE idProduct="+id;
                ste.executeUpdate(sql);   

        System.out.println("produits supprimé , veuillez consulter votre base de données");    }

    @Override
    public void updateproduct(Produits p) throws SQLException {
        FileInputStream input =null;
        try{
        PreparedStatement pre=con.prepareStatement("UPDATE  `debooDB`.`product` SET `idProduct`=?,`productName`=?,`productPrice`=?,`productPicture`=?,`idCategory`=?   WHERE `idProduct`='"+p.getIdProduct()+"'");
      
       
       pre.setInt(1, p.getIdProduct());
    pre.setString(2, p.getProductName());
    pre.setFloat(3, p.getProductPrice());
    
       //upload blob
       
       input = new FileInputStream(new File(p.getProductPicture()));
       pre.setBlob(4,input);   
       pre.setInt(5, p.getCateg().getIdcategory());
      System.out.println(pre);
       pre.executeUpdate();
      System.out.println("produit est mise a jour, veuillez consulter votre BD"); 
        }catch(Exception exc)  {exc.printStackTrace();} 
    }

 /*   @Override
    public List<Produits> readAllproduct() throws SQLException {
List<Produits> arr=new ArrayList<>();
    ste=con.createStatement();
    String ProductPicture = "";
    ResultSet rs=ste.executeQuery("select * from product");
     while (rs.next()) {                
               int idProduct=rs.getInt("idProduct");
               String ProductName=rs.getString("productName");
               float ProductPrice=rs.getFloat(3);
               Blob ProductPicturee=rs.getBlob("ProductPicture");
          
            ProductPicture=ProductPicturee.toString();
               


               int idCategory=rs.getInt("idCategory");
               
               
               Produits prd=new Produits(idProduct,ProductName,ProductPrice,ProductPicture,idCategory);
     arr.add(prd);
     }
    return arr;    }*/

    @Override
    public void ajouterproduct(Produits p) throws SQLException {
        FileInputStream input =null;
        try{
PreparedStatement pre=con.prepareStatement("INSERT INTO `debooDB`.`product` ( `idProduct`, `productName`, `productPrice`,`productPicture`,`idCategory`) VALUES ( ?, ?, ?, ?, ?);");
      
       
       pre.setInt(1, p.getIdProduct());
    pre.setString(2, p.getProductName());
    pre.setFloat(3, p.getProductPrice());
    
       //upload blob
       
       input = new FileInputStream(new File(p.getProductPicture()));
       pre.setBlob(4,input);   
       pre.setInt(5, p.getCateg().getIdcategory());
      System.out.println(pre);
       pre.executeUpdate();
      System.out.println("produit ajouté, veuillez consulter votre BD"); 
        }catch(Exception exc)  {exc.printStackTrace();} 
    }

    @Override
    public void searchbyidproduct(int id) throws SQLException {
    String query="SELECT * FROM product WHERE idProduct='"+id+"'";
        ste=con.createStatement();
     ResultSet rst = ste.executeQuery(query);
        rst.last();
        int nbrRow = rst.getRow();
        if(nbrRow!=0){
            System.out.println("Produit trouve");
        }else{
        System.out.println("Produit non trouve");
        }
    }

 /*   @Override
    public List<Produits> sortedbyId() throws SQLException {
        List<Produits> arr=new ArrayList<>();
    ste=con.createStatement();
    String ProductPicture = "";
    ResultSet rs=ste.executeQuery("select * from product order by idProduct desc");
     while (rs.next()) {                
               int idProduct=rs.getInt("idProduct");
               String ProductName=rs.getString("productName");
               float ProductPrice=rs.getFloat(3);
               Blob ProductPicturee=rs.getBlob("ProductPicture");
          
            ProductPicture=ProductPicturee.toString();
               


               int idCategory=rs.getInt("idCategory");
               
               
               Produits prd=new Produits(idProduct,ProductName,ProductPrice,ProductPicture,idCategory);
     arr.add(prd);
     }
    return arr;
    }
*/
    
    public void readall() throws SQLException{

try{
 ste=con.createStatement();
 ResultSet rs=ste.executeQuery("select * from product");
    ResultSetMetaData rm=rs.getMetaData();
    
    for(int i=2; i<= rm.getColumnCount();i++)
        System.out.println(" "+rm.getCatalogName(i)+"\t");
 
        while(rs.next())
        {
        for(int i=2; i<= rm.getColumnCount();i++)
                System.out.println("\t"+rs.getObject(i).toString()+"\t");
                    System.out.println("---------------");
                    
        
        }
}
catch(Exception e)
                {e.printStackTrace();}
 

}


    @Override
    public void nbreproductbycategory(int idcateg) throws SQLException{
        String rs="SELECT COUNT(*) as countab FROM product WHERE idCategory='"+idcateg+"'";
       ste=con.createStatement();
       ResultSet rset=ste.executeQuery(rs);
       while(rset.next())
       {
           System.out.println("\t"+rset.getString("countab"));
           System.out.println();
       }

    
    //System.out.println(query);
    }

    


   
    
    
}
