/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produit.IService;

import Produit.entite.Produits;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author ghassen
 */
public interface Iserviceproduits<T>{
     void ajouterproduct(Produits t) throws SQLException;
    void deleteproduct(int id) throws SQLException;
    void updateproduct(Produits p) throws SQLException;
    void searchbyidproduct(int id) throws SQLException;
    List<T> sortedbyId() throws SQLException;
    List<T> readAllproduct() throws SQLException;
}
