/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produit.entite;
import category.Entite.Category;
import java.awt.Image;
/**
 *
 * @author ghassen
 */
public class Produits {
     private int idProduct;
    private  String productName;
    private  float productPrice;
    private  String productPicture;
    private  Category Categ;
// private  int idCategory;

    public Produits(int idProduct, String productName, float productPrice,String productPicture,  Category Categ) {
        this.idProduct = idProduct;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productPicture = productPicture;
        this.Categ = Categ;
    }

    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public float getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(float productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductPicture() {
        return productPicture;
    }

    public void setProductPicture(String productPicture) {
        this.productPicture = productPicture;
    }

    public Category getCateg() {
        return Categ;
    }

    public void setCateg(Category Categ) {
        this.Categ = Categ;
    }

    
    
    public Produits() {
    }

    @Override
    public String toString() {
        return "Produits{" + "idProduct=" + idProduct + ", productName=" + productName + ", productPrice=" + productPrice + ", productPicture=" + productPicture + ", Categ=" + Categ + '}';
    }

   
    
}
