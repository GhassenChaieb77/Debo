/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produits.gui;

import Dialog.AlertDialog;
import category.Entite.Category;
import category.Service.Servicecategory;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import deboo.Utils.DataBase;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import static sun.security.krb5.KrbException.errorMessage;

/**
 *
 * @author ghassen
 */
public class produitsController implements Initializable {
    private ObservableList<Category> data;
    private Connection con;
    private ResultSet rs=null;
    private PreparedStatement pst;
    @FXML
    private Label error_idcat;
     @FXML
    private Label error_namecat;
    @FXML
    private TableView<Category> tab_cat;
     @FXML
     private Pane pane_cat,pane_prod;
      @FXML
      private JFXButton btn_cat,btn_prod,add_cat;
      
        @FXML
      private TableColumn<Category,?> Namec;
    @FXML
    private JFXTextField tf_idcat,tf_nomcat;
    
    
       @FXML
       private void handlebuttonAction(ActionEvent event){
            
           if (event.getSource() == btn_cat)
           {
               pane_cat.toFront();
           }
       
           else  if (event.getSource() == btn_prod)
           {
               pane_prod.toFront();
           }
       }
           @FXML
   public void ajoutercat(ActionEvent event) throws SQLException {
        boolean isIdEmpty=validation.TextFieldvalidation.istextFieldTypeNumber(tf_idcat, error_idcat, "id must be number");
        boolean isNameEmpty=validation.TextFieldvalidation.isTextFieldNoEmpty(tf_nomcat, error_namecat, "Name is require");
        if(isIdEmpty && isNameEmpty)
        {
            String idC = tf_idcat.getText();
            String NomC = tf_nomcat.getText();
            int i;
            Servicecategory cat = new Servicecategory();
            int idC1=Integer.valueOf(idC);
            Category c = new Category(idC1,NomC);
            
            i=cat.ajoutercategory(c);
              if(i==1)
        {
            AlertDialog.display("Info","categorie ajoutée");
            loadDatacat();
        }
          
        }     
          
           
        
    }
   

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        con = DataBase.getInstance().getConnection();
         data= FXCollections.observableArrayList();
        affichercat();
       loadDatacat();
        
    }
   
 private void affichercat(){
        
             Namec.setCellValueFactory(new PropertyValueFactory <>("categoryName"));
    }
 private void loadDatacat() {
   
         try {
           pst =con.prepareStatement("Select * from category");

    rs=pst.executeQuery();
     while (rs.next()) {                
             data.add(new Category(rs.getString("categoryName")));
     }       }
       catch (SQLException ex) {
           Logger.getLogger(Servicecategory.class.getName()).log(Level.SEVERE, null, ex);
       }
        tab_cat.setItems(data);
    }
    

    
}
