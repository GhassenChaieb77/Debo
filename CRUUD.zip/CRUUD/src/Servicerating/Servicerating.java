/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicerating;

import IServicerating.IServicerating;
import category.Entite.Category;
import deboo.Utils.DataBase;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import rating.entite.Rating;

/**
 *
 * @author ghassen
 */
public class Servicerating implements IServicerating{

   private Connection con;
    private Statement ste;

    public Servicerating() {
        con = DataBase.getInstance().getConnection();

    }
    @Override
    public void ajouterrating(Rating t) throws SQLException {
ste = con.createStatement();
        String requeteInsert = "INSERT INTO `debooDB`.`rating` (`idNote`, `note`, `idProduct`) VALUES ('" + t.getIdNote()+ "', '" + t.getNote() + "', '" + t.getIdProduct() + "');";
        ste.executeUpdate(requeteInsert);   
    System.out.println("note ajoutée, veuillez consulter votre BD");    }

    @Override
    public void deleterating(int id) throws SQLException {
ste=con.createStatement();
        String sql="DELETE FROM `debooDB`.`rating` WHERE idNote="+id;
                ste.executeUpdate(sql);   

        System.out.println("note supprimé , veuillez consulter votre base de données");    }

    @Override
    public void updaterating(int idNote, int note, int idProduct) throws SQLException {
ste = con.createStatement();
String requestUpdate= "UPDATE debooDB.`rating` SET `idNote`='"+idNote+"',`note`='"+note+"',`idProduct`='"+idProduct+"' WHERE `idNote`='"+idNote+"';"; 
                  
        
         ste.executeUpdate(requestUpdate);
//       
         System.out.println("note modifié, veuillez consulter votre BD");    }

    @Override
    public List<Rating> readAllrating() throws SQLException {
List<Rating> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from rating");
     while (rs.next()) {                
               int idNote=rs.getInt(1);
               int note=rs.getInt(2);
               int idProduct=rs.getInt(3);
               
              Rating rate=new Rating(idNote,note,idProduct);
     arr.add(rate);
     }
    return arr;
    }     }
    

