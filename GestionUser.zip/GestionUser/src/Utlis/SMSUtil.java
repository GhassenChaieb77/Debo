/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utlis;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.JOptionPane;


import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;


/**
 *
 * @author USER
 */

public class SMSUtil {
    
    public static final String ACCOUNT_SID = "AC32a3c49700934481addd5ce1659f04d2";
  public static final String AUTH_TOKEN = "{{ auth_token }}";

     public SMSUtil() {
    }
     
     
    public void sendsms()
    {

   try {
   // Construc
  
    String apiKey = "apikey=" + "0wwyXJxH7GM-xRDPgzM40R1VRnXzW3Hibneyjq2OFh";
String message = "&message=" + "stfu";
String sender = "&sender=" + "test";
String numbers = "&numbers=" + "0021652149807";
			
   
   
   // Send data
   HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/send/?").openConnection();
   String data = apiKey + numbers + message + sender;
   conn.setDoOutput(true);
   conn.setRequestMethod("POST");
   conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
   conn.getOutputStream().write(data.getBytes("UTF-8"));
   final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
   final StringBuffer stringBuffer = new StringBuffer();
   String line;
   while ((line = rd.readLine()) != null) {
    //stringBuffer.append(line);
    JOptionPane.showMessageDialog(null, "message"+line);
   }
   rd.close();
    
   //return stringBuffer.toString();
  } catch (Exception e) {
   //System.out.println("Error SMS "+e);
    JOptionPane.showMessageDialog(null, e);
   //return "Error "+e;            }

  }
    }

   
      public void sms2()
              
      {
            Twilio.init("ACc976b15faf4b646a2e3038c6943f9692", "6c729456ba653972c5e347833ca351e0");

      Message message = Message.creator(new PhoneNumber("+21627859535"),
        new PhoneNumber("+12056199796"), 
        "hi").create();

    System.out.println(message.getSid());

      }
  
}
     
