
package Utlis;

import Entity.User;
import Utlis.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserController   {
    
    
     Connection con;
    PreparedStatement preparedStatement;
    ResultSet resultSet;
     private Statement ste;

    public UserController() {
                con =Database.getInstance().getConnection();

    }
    
        
  public void Add() throws SQLException
    {
    PreparedStatement pre=con.prepareStatement("INSERT INTO `deboodb`.`fos_users` (`username`, `email`, `password`, `roles`) VALUES(?,?,?,?)");
    pre.setString(1, "");
    pre.setString(2, "");
    pre.setString(3, "");
    pre.setString(4, "client");
    pre.executeUpdate();
    
    
    }
  
     public List<User> readAll() throws SQLException {
    List<User> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from fos_users");
    
    
    
     while (rs.next()) {                
               int id=rs.getInt("id");
               String username=rs.getString("username");
               String email=rs.getString("email");
               User u=new User(id,username,email);
     arr.add(u);
     }
     
    return arr;
    }

 public boolean delete(User u) throws SQLException {
       ste = con.createStatement();
      String requeteInsert ="DELETE FROM  `deboodb`.`fos_users` WHERE id ="+u.getId();
       return ste.executeUpdate(requeteInsert)==1;
 }
  
    public boolean update(User u) throws SQLException {
      String query  ="UPDATE deboodb.`fos_users` SET `username`=?  WHERE email =?";
      System.out.println(u.getUsername()); 
        preparedStatement = con.prepareStatement(query);        
        preparedStatement.setString(1, u.getUsername());
        preparedStatement.setString(2, u.getEmail());
        return preparedStatement.executeUpdate()==1;  
    }
    
    
     public User FindUserById(int id) throws SQLException {
    ste=con.createStatement();
    User u = null;
        String sql ="select * from fos_users where id=?";        
          preparedStatement  = con.prepareStatement(sql);
          preparedStatement.setInt(1, id);
         ResultSet rs = preparedStatement.executeQuery();          
             
         while (rs.next()) {                
               String usename=rs.getString("username");
               String email=rs.getString("email");
               u=new User(rs.getInt("id"),usename,email);
     }
     return u;
    }
    
     
      public User FindUserByLogin(String log) throws SQLException {
    ste=con.createStatement();
    User u = null;
        String sql ="select * from fos_users where username=?";        
          preparedStatement  = con.prepareStatement(sql);
          preparedStatement.setString(1, log);
         ResultSet rs = preparedStatement.executeQuery();          
             
         while (rs.next()) {                
               int Cin=rs.getInt("id");
             String usename=rs.getString("username");
             String email=rs.getString("email");
                u=new User(Cin,usename,email);
     }
     return u;
    }
     
   //public List<User> Sort(User u) throws SQLException {
    public List<User> Sort() throws SQLException {
    List<User> arr=new ArrayList<>();
    ste=con.createStatement();
  ResultSet rs=ste.executeQuery("select * from fos_users Order BY username ");

     while (rs.next()) {                
               int Cin=rs.getInt("id");
               String lastname=rs.getString("username");
               String firstname=rs.getString("email");
               User u=new User(Cin,lastname,firstname);
     arr.add(u);
     }
  
    return arr;
    }

  	
      
}
