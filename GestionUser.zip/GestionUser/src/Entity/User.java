/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;


public class User    
{

private int Cin;

    private String login;

    private String password;

    private int phone;

    private String lastname;

    private String firstname;
    
    
      public User() {
    }

    public User(int Cin, String login, String password, int phone, String lastname, String firstname) {
        this.Cin = Cin;
        this.login = login;
        this.password = password;
        this.phone = phone;
        this.lastname = lastname;
        this.firstname = firstname;
    }

    public User(int Cin, int phone, String lastname, String firstname) {
        this.Cin = Cin;
        this.phone = phone;
        this.lastname = lastname;
        this.firstname = firstname;
    }

  



    public int getCin() {
        return Cin;
    }

    public void setCin(int Cin) {
        this.Cin = Cin;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    @Override
    public String toString() {
        return "User{" + "Cin=" + Cin + ", login=" + login + ", password=" + password + ", phone=" + phone + ", lastname=" + lastname + ", firstname=" + firstname + '}';
    }

    
    
    

}