/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionuser;

import Controller.LoginController;
import Controller.UserController;
import Entity.User;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author USER
 */
public class GestionUser {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        
        
LoginController ser = new LoginController();
UserController service = new UserController();
User u1 = new User(984414255,"Ghassen","password",9852222,"ghassen","chaieb");
ser.logIn("admin","system");
ser.logIn("amine22","amine227");
//service.delete(u1);
 // service.Add(u1);
List<User> list = service.readAll();
System.out.println(list); 
u1.setPhone(525);
  service.update(u1);
       }   

}
    

