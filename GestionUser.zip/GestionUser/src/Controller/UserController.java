
package Controller;

import Entity.User;
import Utlis.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class UserController {
    
     Connection con;
    PreparedStatement preparedStatement;
    ResultSet resultSet;

    public UserController() {
                con =Database.getInstance().getConnection();

    }
    
    
    
     private Statement ste;
  public void Add(User u) throws SQLException
    {
    PreparedStatement pre=con.prepareStatement("INSERT INTO `deboodb`.`User` (`cin`, `lastName`, `firstName`, `phone1`, `login`, `password`, `role`) VALUES(?,?,?,?,?,?,?)");
    pre.setInt(1, u.getCin());
    pre.setString(2, u.getFirstname());
    pre.setString(3, u.getLastname());
    pre.setInt(4, u.getPhone());
    pre.setString(5, u.getLogin());
    pre.setString(6, u.getPassword());
    pre.setString(7, "client");

    pre.executeUpdate();
    }
      
     public List<User> readAll() throws SQLException {
    List<User> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from User");
     while (rs.next()) {                
               int Cin=rs.getInt("cin");
               String lastname=rs.getString("lastName");
               String firstname=rs.getString("firstName");
               int phone=rs.getInt("phone1");
               User u=new User(Cin,phone,lastname,firstname);
     arr.add(u);
     }
    return arr;
    }

    public boolean delete(User u) throws SQLException {
        ste = con.createStatement();
        String requeteInsert ="DELETE FROM  `deboodb`.`User` WHERE cin ="+u.getCin();
        return ste.executeUpdate(requeteInsert)==1;
 
    }

  
    public boolean update(User u) throws SQLException {
       String query  ="UPDATE `deboodb`.`User` SET `phone1`=?  WHERE cin =?";
               con.setAutoCommit(false);

        preparedStatement = con.prepareStatement(query);
        System.out.println(u.getPhone());
        preparedStatement.setInt(1, u.getPhone());
        preparedStatement.setInt(2, u.getCin());
        return preparedStatement.executeUpdate()==1;
        
        
    }
}
