/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUi;

import Entity.User;
import Utlis.Database;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class FXMLController implements Initializable {

    @FXML
    private TableView<User> tblData;
    @FXML
    private TableColumn<User, String> idtext;
    @FXML
    private TableColumn<User, String> usernametxt;
    @FXML
    private TableColumn<User, String> emailtxt;

        private ObservableList<User> data =FXCollections.observableArrayList();

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
            Connection con = Database.getInstance().getConnection();
            
        try {
            ResultSet rs =con.createStatement().executeQuery("SELECT `id`, `username`,  `email` FROM `fos_users`");
            
                 while (rs.next()) {                
               data.add(new User(rs.getString("id"), rs.getString("username"), rs.getString("email")));
                 }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            idtext.setCellValueFactory((new PropertyValueFactory<>("id")));
            usernametxt.setCellValueFactory((new PropertyValueFactory<>("username")));
            emailtxt.setCellValueFactory((new PropertyValueFactory<>("email")));
    
            tblData.setItems(data);
    }    
    
}
